<template>
  <v-list :type="'Android'"></v-list>
</template>

<script type="text/ecmascript-6">
  import vList from './list.vue';
  export default {
    components: {
      vList
    }
  };
</script>
<style lang="stylus" rel="stylesheet/stylus">
</style>
